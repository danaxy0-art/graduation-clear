import "../styles/admin-dashboard.css";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { Users, UserCheck, UserX, Upload, LayoutDashboard } from "lucide-react";

export default function AdminDashboard() {
  const navigate = useNavigate();

  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [totalStudents, setTotalStudents] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    setLoading(true);

    const { count, error: countError } = await supabase
      .from("students")
      .select("*", { count: "exact", head: true });

    if (countError) {
      alert(countError.message);
      setLoading(false);
      return;
    }

    const { data: studentsData, error: studentsError } = await supabase
      .from("students")
      .select("*")
      .order("id", { ascending: true })
      .limit(2000);

    if (studentsError) {
      alert(studentsError.message);
      setLoading(false);
      return;
    }

    const { data: attendanceData, error: attendanceError } = await supabase
      .from("attendance")
      .select("*");

    if (attendanceError) {
      alert(attendanceError.message);
      setLoading(false);
      return;
    }

    setTotalStudents(count || 0);
    setStudents(studentsData || []);
    setAttendance(attendanceData || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const presentIds = new Set(attendance.map((item) => Number(item.student_id)));

  const presentStudents = students.filter((student) =>
    presentIds.has(Number(student.id)),
  );

  const absentStudents = students.filter(
    (student) => !presentIds.has(Number(student.id)),
  );

  const total = totalStudents;
  const presentCount = presentStudents.length;
  const absentCount = total - presentCount;
  const rate = total > 0 ? Math.round((presentCount / total) * 100) : 0;

  return (
    <div className="flex min-h-screen bg-slate-100">
      <aside className="w-64 bg-[#0B3D91] text-white flex flex-col">
        <div className="p-6 border-b border-blue-700">
          <h1 className="font-bold text-xl">KSU Attendance</h1>
          <p className="text-sm opacity-80">Graduation System</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => navigate("/dashboard")}
            className="w-full flex items-center gap-3 p-3 rounded-lg bg-white text-[#0B3D91] font-medium"
          >
            <LayoutDashboard size={18} />
            Dashboard
          </button>

          <button
            onClick={() => navigate("/present")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <UserCheck size={18} />
            Present Students
          </button>

          <button
            onClick={() => navigate("/absent")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <UserX size={18} />
            Absent Students
          </button>

          <button
            onClick={() => navigate("/excel")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <Upload size={18} />
            Excel Upload
          </button>
        </nav>

        <div className="p-4 border-t border-blue-700">
          <button
            onClick={() => {
              localStorage.clear();
              navigate("/admin");
            }}
            className="w-full bg-red-500 hover:bg-red-600 p-3 rounded-lg font-medium"
          >
            Logout
          </button>
        </div>
      </aside>

      <main className="flex-1 p-8">
        <h1 className="text-2xl font-bold text-slate-800">
          Welcome to Graduation Entry
        </h1>

        <p className="text-slate-500 mt-1">Student Attendance Dashboard</p>

        {loading ? (
          <p className="mt-8">Loading...</p>
        ) : (
          <>
            <div className="grid md:grid-cols-4 gap-5 mt-8">
              <div className="bg-white rounded-2xl p-5 shadow">
                <Users className="text-blue-700" />
                <h3 className="mt-3 text-slate-500">Total Students</h3>
                <p className="text-3xl font-bold">{total}</p>
              </div>

              <div className="bg-white rounded-2xl p-5 shadow">
                <UserCheck className="text-green-600" />
                <h3 className="mt-3 text-slate-500">Present</h3>
                <p className="text-3xl font-bold">{presentCount}</p>
              </div>

              <div className="bg-white rounded-2xl p-5 shadow">
                <UserX className="text-red-600" />
                <h3 className="mt-3 text-slate-500">Absent</h3>
                <p className="text-3xl font-bold">{absentCount}</p>
              </div>

              <div className="bg-white rounded-2xl p-5 shadow">
                <Users className="text-purple-600" />
                <h3 className="mt-3 text-slate-500">Attendance Rate</h3>
                <p className="text-3xl font-bold">{rate}%</p>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-6 mt-8">
              <div className="bg-white rounded-2xl shadow">
                <div className="bg-green-500 text-white px-5 py-3 rounded-t-2xl">
                  Present Students
                </div>

                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="p-3 text-left">Name</th>
                      <th className="p-3 text-left">Serial</th>
                    </tr>
                  </thead>

                  <tbody>
                    {presentStudents.slice(0, 5).map((student) => (
                      <tr key={student.id} className="border-b">
                        <td className="p-3">{student.student_name}</td>
                        <td className="p-3">{student.student_id}</td>
                      </tr>
                    ))}

                    {presentStudents.length === 0 && (
                      <tr>
                        <td className="p-3 text-slate-500" colSpan="2">
                          No present students yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="bg-white rounded-2xl shadow">
                <div className="bg-red-500 text-white px-5 py-3 rounded-t-2xl">
                  Absent Students
                </div>

                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="p-3 text-left">Name</th>
                      <th className="p-3 text-left">Serial</th>
                    </tr>
                  </thead>

                  <tbody>
                    {absentStudents.slice(0, 5).map((student) => (
                      <tr key={student.id} className="border-b">
                        <td className="p-3">{student.student_name}</td>
                        <td className="p-3">{student.student_id}</td>
                      </tr>
                    ))}

                    {absentStudents.length === 0 && (
                      <tr>
                        <td className="p-3 text-slate-500" colSpan="2">
                          No absent students
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
