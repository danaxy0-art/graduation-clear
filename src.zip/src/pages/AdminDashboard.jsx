import "../styles/admin-dashboard.css";
import { useNavigate } from "react-router-dom";

import { Users, UserCheck, UserX, Upload, LayoutDashboard } from "lucide-react";

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen bg-slate-100">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0B3D91] text-white flex flex-col">
        <div className="p-6 border-b border-blue-700">
          <h1 className="font-bold text-xl">KSU Attendance</h1>
          <p className="text-sm opacity-80">Graduation System</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <button
            onClick={() => navigate("/dashboard")}
            className="w-full flex items-center gap-3 p-3 rounded-lg bg-white text-[#0B3D91] font-medium"
          >
            <LayoutDashboard size={18} />
            Dashboard
          </button>

          <button
            onClick={() => navigate("/present")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <UserCheck size={18} />
            Present Students
          </button>

          <button
            onClick={() => navigate("/absent")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <UserX size={18} />
            Absent Students
          </button>

          <button
            onClick={() => navigate("/excel")}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-blue-800"
          >
            <Upload size={18} />
            Excel Upload
          </button>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-blue-700">
          <button
            onClick={() => {
              localStorage.removeItem("admin");
              navigate("/admin");
            }}
            className="w-full bg-red-500 hover:bg-red-600 p-3 rounded-lg font-medium"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <h1 className="text-2xl font-bold text-slate-800">
          Welcome to Graduation Entry
        </h1>

        <p className="text-slate-500 mt-1">Student Attendance Dashboard</p>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-5 mt-8">
          <div className="bg-white rounded-2xl p-5 shadow">
            <Users className="text-blue-700" />
            <h3 className="mt-3 text-slate-500">Total Students</h3>
            <p className="text-3xl font-bold">1500</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow">
            <UserCheck className="text-green-600" />
            <h3 className="mt-3 text-slate-500">Present</h3>
            <p className="text-3xl font-bold">847</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow">
            <UserX className="text-red-600" />
            <h3 className="mt-3 text-slate-500">Absent</h3>
            <p className="text-3xl font-bold">653</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow">
            <Users className="text-purple-600" />
            <h3 className="mt-3 text-slate-500">Attendance Rate</h3>
            <p className="text-3xl font-bold">56%</p>
          </div>
        </div>

        {/* Tables */}
        <div className="grid lg:grid-cols-2 gap-6 mt-8">
          {/* Present */}
          <div className="bg-white rounded-2xl shadow">
            <div className="bg-green-500 text-white px-5 py-3 rounded-t-2xl">
              Present Students
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">Serial</th>
                </tr>
              </thead>

              <tbody>
                {[1, 2, 3, 4, 5].map((item) => (
                  <tr key={item} className="border-b">
                    <td className="p-3">Student {item}</td>
                    <td className="p-3">#{item}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Absent */}
          <div className="bg-white rounded-2xl shadow">
            <div className="bg-red-500 text-white px-5 py-3 rounded-t-2xl">
              Absent Students
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">Serial</th>
                </tr>
              </thead>

              <tbody>
                {[1, 2, 3, 4, 5].map((item) => (
                  <tr key={item} className="border-b">
                    <td className="p-3">Student {item}</td>
                    <td className="p-3">#{item + 100}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
