import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <div className="bg-white p-10 rounded-3xl shadow-xl w-[400px] text-center">
        
        <h1 className="text-2xl font-bold mb-2">
          Graduation Attendance System
        </h1>

        <p className="text-gray-500 mb-8">
          Choose Login Type
        </p>

        <div className="space-y-4">
          
          {/* Student Login */}
          <button
            onClick={() => navigate("/student-login")}
            className="w-full bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700"
          >
            Student Login
          </button>

          {/* Admin Login */}
          <button
            onClick={() => navigate("/admin")}
            className="w-full bg-[#0B3D91] text-white p-3 rounded-xl hover:opacity-90"
          >
            Admin Login
          </button>

        </div>
      </div>
    </div>
  );
}