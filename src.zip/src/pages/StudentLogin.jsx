import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";

export default function StudentLogin() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [serial, setSerial] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!name.trim() || !serial.trim()) {
      alert("Please fill all fields");
      return;
    }

    setLoading(true);

    const { data, error } = await supabase
      .from("students")
      .select("*")
      .eq("student_id", serial.trim())
      .single();

    setLoading(false);

    if (error || !data) {
      alert("Student not found");
      return;
    }

    if (data.student_name.trim().toLowerCase() !== name.trim().toLowerCase()) {
      alert("Name does not match this serial number");
      return;
    }

    localStorage.setItem("studentDbId", data.id);
    localStorage.setItem("studentId", data.student_id);
    localStorage.setItem("studentName", data.student_name);

    navigate("/student");
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[380px] rounded-3xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center">
            🎓
          </div>

          <h1 className="font-bold text-xl mt-4">Student Login</h1>
          <p className="text-slate-500 text-sm">Graduation Attendance System</p>
        </div>

        <input
          placeholder="Full Name"
          className="w-full border rounded-xl p-3 mb-4"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="number"
          placeholder="Serial Number"
          className="w-full border rounded-xl p-3 mb-4"
          value={serial}
          onChange={(e) => setSerial(e.target.value)}
        />

        <button
          onClick={submit}
          disabled={loading}
          className="w-full bg-[#0B3D91] text-white py-3 rounded-xl disabled:opacity-50"
        >
          {loading ? "Checking..." : "Continue"}
        </button>
      </div>
    </div>
  );
}
