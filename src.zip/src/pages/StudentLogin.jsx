import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function StudentLogin() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [serial, setSerial] = useState("");

  const submit = () => {
    if (!name || !serial) {
      alert("Please fill all fields");
      return;
    }

    if (serial < 1 || serial > 1500) {
      alert("Serial Number must be between 1 and 1500");
      return;
    }

    localStorage.setItem("studentName", name);
    localStorage.setItem("studentSerial", serial);

    navigate("/student");
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[380px] rounded-3xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center">
            🎓
          </div>

          <h1 className="font-bold text-xl mt-4">Student Login</h1>

          <p className="text-slate-500 text-sm">Graduation Attendance System</p>
        </div>

        <input
          placeholder="Full Name"
          className="w-full border rounded-xl p-3 mb-4"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="number"
          placeholder="Serial Number"
          className="w-full border rounded-xl p-3 mb-4"
          value={serial}
          onChange={(e) => setSerial(e.target.value)}
        />

        <button
          onClick={submit}
          className="w-full bg-[#0B3D91] text-white py-3 rounded-xl"
        >
          Continue
        </button>
      </div>
    </div>
  );
}
