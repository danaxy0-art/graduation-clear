import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function StudentDashboard() {
  const studentDbId = localStorage.getItem("studentDbId");

  const [student, setStudent] = useState(null);
  const [attended, setAttended] = useState(false);
  const [loading, setLoading] = useState(true);

  const today = new Date().toISOString().split("T")[0];

  useEffect(() => {
    const fetchData = async () => {
      if (!studentDbId) {
        alert("Please login again");
        setLoading(false);
        return;
      }

      const { data: studentData, error: studentError } = await supabase
        .from("students")
        .select("*")
        .eq("id", studentDbId)
        .single();

      if (studentError || !studentData) {
        alert("Student not found");
        setLoading(false);
        return;
      }

      setStudent(studentData);

      const { data: attendanceData } = await supabase
        .from("attendance")
        .select("*")
        .eq("student_id", studentDbId)
        .eq("attendance_date", today);

      if (attendanceData && attendanceData.length > 0) {
        setAttended(true);
      }

      setLoading(false);
    };

    fetchData();
  }, [studentDbId, today]);

  const markAttendance = async () => {
    if (!student) {
      alert("Student data not found");
      return;
    }

    const { data: existing } = await supabase
      .from("attendance")
      .select("*")
      .eq("student_id", student.id)
      .eq("attendance_date", today);

    if (existing && existing.length > 0) {
      setAttended(true);
      alert("You have already marked your attendance.");
      return;
    }

    const { error } = await supabase.from("attendance").insert([
      {
        student_id: student.id,
        attendance_date: today,
      },
    ]);

    if (error) {
      alert(error.message);
      return;
    }

    setAttended(true);
    alert("Attendance recorded successfully");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-100 flex justify-center items-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[500px] rounded-3xl shadow-xl p-8">
        <div className="text-center">
          <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto flex items-center justify-center text-3xl">
            🎓
          </div>

          <h1 className="text-2xl font-bold mt-4">Welcome</h1>
          <p className="text-slate-500 mt-2">Graduation Attendance System</p>
        </div>

        <div className="mt-8 space-y-4">
          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Student Name</h3>
            <p>{student?.student_name}</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Serial Number</h3>
            <p>{student?.student_id}</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Attendance Status</h3>
            <p
              className={
                attended ? "text-green-600 font-bold" : "text-red-600 font-bold"
              }
            >
              {attended ? "Present" : "Not Marked"}
            </p>
          </div>
        </div>

        <button
          onClick={markAttendance}
          disabled={attended}
          className={`w-full mt-6 py-3 rounded-xl text-white ${
            attended ? "bg-green-600" : "bg-[#0B3D91]"
          }`}
        >
          {attended ? "Attendance Recorded" : "Mark Attendance"}
        </button>
      </div>
    </div>
  );
}
