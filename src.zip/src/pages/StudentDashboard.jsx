import { useState } from "react";

export default function StudentDashboard() {
  const name = localStorage.getItem("studentName");
  const serial = localStorage.getItem("studentSerial");

  const [attended, setAttended] = useState(false);

  const markAttendance = () => {
    const today = new Date().toDateString();

    const existingAttendance = localStorage.getItem(
      `attendance-${serial}-${today}`,
    );

    if (existingAttendance) {
      alert("You have already marked your attendance.");
      return;
    }

    localStorage.setItem(`attendance-${serial}-${today}`, "present");

    setAttended(true);

    alert("Attendance recorded successfully");
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[500px] rounded-3xl shadow-xl p-8">
        <div className="text-center">
          <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto flex items-center justify-center text-3xl">
            🎓
          </div>

          <h1 className="text-2xl font-bold mt-4">Welcome</h1>

          <p className="text-slate-500 mt-2">Graduation Attendance System</p>
        </div>

        <div className="mt-8 space-y-4">
          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Student Name</h3>

            <p>{name}</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Serial Number</h3>

            <p>{serial}</p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold">Attendance Status</h3>

            <p
              className={
                attended ? "text-green-600 font-bold" : "text-red-600 font-bold"
              }
            >
              {attended ? "Present" : "Not Marked"}
            </p>
          </div>
        </div>

        <button
          onClick={markAttendance}
          disabled={attended}
          className={`w-full mt-6 py-3 rounded-xl text-white ${
            attended ? "bg-green-600" : "bg-[#0B3D91]"
          }`}
        >
          {attended ? "Attendance Recorded" : "Mark Attendance"}
        </button>
      </div>
    </div>
  );
}
