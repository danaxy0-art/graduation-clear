import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import Sidebar from "../components/Sidebar";
import "../styles/absent.css";

export default function AbsentStudents() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAbsentStudents();
  }, []);

  const fetchAbsentStudents = async () => {
    setLoading(true);

    let allStudents = [];
    let from = 0;
    const pageSize = 1000;

    while (true) {
      const { data, error } = await supabase
        .from("students")
        .select("*")
        .order("id", { ascending: true })
        .range(from, from + pageSize - 1);

      if (error) {
        alert(error.message);
        setLoading(false);
        return;
      }

      allStudents = [...allStudents, ...(data || [])];

      if (!data || data.length < pageSize) break;

      from += pageSize;
    }

    const { data: attendanceData, error: attendanceError } = await supabase
      .from("attendance")
      .select("student_id");

    if (attendanceError) {
      alert(attendanceError.message);
      setLoading(false);
      return;
    }

    const presentIds = new Set(
      attendanceData.map((item) => Number(item.student_id)),
    );

    const absentStudents = allStudents.filter(
      (student) => !presentIds.has(Number(student.id)),
    );

    setStudents(absentStudents);
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar />

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold">Absent Students</h1>

        <div className="bg-white rounded-2xl shadow mt-8">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">Name</th>
                <th className="text-left p-4">Serial</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td className="p-4" colSpan="2">
                    Loading...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td className="p-4" colSpan="2">
                    No absent students
                  </td>
                </tr>
              ) : (
                students.map((student) => (
                  <tr key={student.id} className="border-b">
                    <td className="p-4">{student.student_name}</td>
                    <td className="p-4">{student.student_id}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
