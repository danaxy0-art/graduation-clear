import Sidebar from "../components/Sidebar";
import StatCard from "../components/StatCard";
import "../styles/admin-dashboard.css";

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar />

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold">Welcome to Graduation Entry</h1>

        <p className="text-slate-500 mt-2">Student Attendance Dashboard</p>

        <div className="grid md:grid-cols-4 gap-5 mt-8">
          <StatCard title="Total Students" value="1500" />

          <StatCard title="Present" value="0" />

          <StatCard title="Absent" value="1500" />

          <StatCard title="Attendance Rate" value="0%" />
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mt-10">
          <div className="bg-white rounded-2xl shadow">
            <div className="bg-green-500 text-white p-4 rounded-t-2xl">
              Present Students
            </div>

            <div className="p-4">No attendance yet</div>
          </div>

          <div className="bg-white rounded-2xl shadow">
            <div className="bg-red-500 text-white p-4 rounded-t-2xl">
              Absent Students
            </div>

            <div className="p-4">Waiting for attendance</div>
          </div>
        </div>
      </main>
    </div>
  );
}
