import Sidebar from "../components/Sidebar";
import "../styles/excel.css";

export default function ExcelUpload() {
  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar />

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold">Excel Upload</h1>

        <div className="bg-white rounded-2xl shadow p-8 mt-8">
          <input
            type="file"
            accept=".xlsx,.xls"
            className="border p-3 rounded-xl"
          />

          <button className="bg-[#0B3D91] text-white px-5 py-3 rounded-xl ml-4">
            Upload
          </button>
        </div>
      </main>
    </div>
  );
}
