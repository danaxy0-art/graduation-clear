import Sidebar from "../components/Sidebar";
import "../styles/present.css";

export default function PresentStudents() {
  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar />

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold">Present Students</h1>

        <div className="bg-white rounded-2xl shadow mt-8">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">Name</th>

                <th className="text-left p-4">Serial</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td className="p-4">Example Student</td>

                <td className="p-4">100</td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
