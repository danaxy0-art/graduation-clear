import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import Sidebar from "../components/Sidebar";
import "../styles/present.css";

export default function PresentStudents() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPresentStudents();
  }, []);

  const fetchPresentStudents = async () => {
    setLoading(true);

    const { data: attendanceData, error: attendanceError } = await supabase
      .from("attendance")
      .select("student_id");

    if (attendanceError) {
      alert(attendanceError.message);
      setLoading(false);
      return;
    }

    const ids = attendanceData.map((item) => item.student_id);

    if (ids.length === 0) {
      setStudents([]);
      setLoading(false);
      return;
    }

    const { data: studentsData, error: studentsError } = await supabase
      .from("students")
      .select("*")
      .in("id", ids);

    if (studentsError) {
      alert(studentsError.message);
      setLoading(false);
      return;
    }

    setStudents(studentsData || []);
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar />

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold">Present Students</h1>

        <div className="bg-white rounded-2xl shadow mt-8">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">Name</th>
                <th className="text-left p-4">Serial</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td className="p-4" colSpan="2">
                    Loading...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td className="p-4" colSpan="2">
                    No present students
                  </td>
                </tr>
              ) : (
                students.map((student) => (
                  <tr key={student.id} className="border-b">
                    <td className="p-4">{student.student_name}</td>
                    <td className="p-4">{student.student_id}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
