import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import "../styles/admin-login.css";

export default function AdminLogin() {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const login = async () => {
    if (!username.trim() || !password.trim()) {
      alert("Please fill all fields");
      return;
    }

    setLoading(true);

    const { data, error } = await supabase
      .from("admins")
      .select("*")
      .ilike("username", username.trim());

    setLoading(false);

    console.log("typed username:", username.trim());
    console.log("typed password:", password.trim());
    console.log("data:", data);
    console.log("error:", error);

    if (error) {
      alert(error.message);
      return;
    }

    if (!data || data.length === 0) {
      alert("Username not found");
      return;
    }

    const admin = data[0];

    if (String(admin.password).trim() !== password.trim()) {
      alert("Wrong password");
      return;
    }

    localStorage.setItem("admin", "true");
    localStorage.setItem("adminId", admin.id);
    localStorage.setItem("adminName", admin.username);
    localStorage.setItem("role", "admin");

    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[400px] rounded-3xl shadow-xl p-8">
        <h1 className="text-center text-2xl font-bold mb-6">Admin Login</h1>

        <input
          placeholder="Username"
          className="w-full border p-3 rounded-xl mb-4"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full border p-3 rounded-xl"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={login}
          disabled={loading}
          className="w-full bg-[#0B3D91] text-white p-3 rounded-xl mt-5 disabled:opacity-50"
        >
          {loading ? "Checking..." : "Login"}
        </button>
      </div>
    </div>
  );
}
