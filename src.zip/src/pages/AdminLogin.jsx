import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/admin-login.css";

export default function AdminLogin() {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const login = () => {
    if (username === "admin" && password === "123456") {
      localStorage.setItem("admin", "true");
      navigate("/dashboard");
    } else {
      alert("Invalid credentials");
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center items-center">
      <div className="bg-white w-[400px] rounded-3xl shadow-xl p-8">
        <h1 className="text-center text-2xl font-bold mb-6">Admin Login</h1>

        <input
          placeholder="Username"
          className="w-full border p-3 rounded-xl mb-4"
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full border p-3 rounded-xl"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={login}
          className="w-full bg-[#0B3D91] text-white p-3 rounded-xl mt-5"
        >
          Login
        </button>
      </div>
    </div>
  );
}
