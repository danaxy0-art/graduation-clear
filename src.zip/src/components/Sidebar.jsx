import {
  LayoutDashboard,
  UserCheck,
  UserX,
  Upload
} from "lucide-react";

import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <aside className="w-64 bg-[#0B3D91] text-white min-h-screen">

      <div className="p-6 border-b">
        <h1 className="font-bold text-xl">
          KSU Attendance
        </h1>
      </div>

      <nav className="p-4 space-y-2">

        <Link
          to="/dashboard"
          className="flex gap-2 p-3 rounded-lg hover:bg-blue-800"
        >
          <LayoutDashboard size={18}/>
          Dashboard
        </Link>

        <Link
          to="/present"
          className="flex gap-2 p-3 rounded-lg hover:bg-blue-800"
        >
          <UserCheck size={18}/>
          Present
        </Link>

        <Link
          to="/absent"
          className="flex gap-2 p-3 rounded-lg hover:bg-blue-800"
        >
          <UserX size={18}/>
          Absent
        </Link>

        <Link
          to="/excel"
          className="flex gap-2 p-3 rounded-lg hover:bg-blue-800"
        >
          <Upload size={18}/>
          Excel Upload
        </Link>

      </nav>

    </aside>
  );
}