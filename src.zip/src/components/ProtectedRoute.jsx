import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children, role }) {
  const userRole = localStorage.getItem("role");

  if (role && userRole !== role) {
    return <Navigate to="/" />;
  }

  return children;
}
