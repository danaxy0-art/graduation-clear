export default function StatCard({
  title,
  value,
  icon
}) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow">

      <div>{icon}</div>

      <h3 className="text-gray-500 mt-3">
        {title}
      </h3>

      <p className="text-3xl font-bold">
        {value}
      </p>

    </div>
  );
}