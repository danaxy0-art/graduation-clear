import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import StudentLogin from "./pages/StudentLogin";
import StudentDashboard from "./pages/StudentDashboard";

import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import PresentStudents from "./pages/PresentStudents";
import AbsentStudents from "./pages/AbsentStudents";
import ExcelUpload from "./pages/ExcelUpload";

import ProtectedRoute from "./components/ProtectedRoute";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />

        <Route path="/student-login" element={<StudentLogin />} />

        <Route
          path="/student"
          element={
            <ProtectedRoute role="student">
              <StudentDashboard />
            </ProtectedRoute>
          }
        />

        <Route path="/admin" element={<AdminLogin />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/present"
          element={
            <ProtectedRoute role="admin">
              <PresentStudents />
            </ProtectedRoute>
          }
        />

        <Route
          path="/absent"
          element={
            <ProtectedRoute role="admin">
              <AbsentStudents />
            </ProtectedRoute>
          }
        />

        <Route
          path="/excel"
          element={
            <ProtectedRoute role="admin">
              <ExcelUpload />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
